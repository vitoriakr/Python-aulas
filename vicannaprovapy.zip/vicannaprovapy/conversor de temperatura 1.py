celsius = int(input('Digite uma temperatura em celsius: '))
fahrenheit = (celsius*1.8)+32
kelvin = celsius+273.15
print('O valor de celsius convertido para Fahrenheit é igual a: ', fahrenheit)
print('O valor de celsius convertido para Kelvin é igual a: ', kelvin)
