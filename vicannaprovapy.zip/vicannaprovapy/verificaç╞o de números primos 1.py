n=int(input('Digite um número: '))
if n%2==0 or n%3==0:
    print('Esse número não é primo')
else:
    print('Esse número é primo!')