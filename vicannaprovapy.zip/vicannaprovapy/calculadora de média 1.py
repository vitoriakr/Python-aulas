lista = 1, 2, 3, 4, 5, 6, 7, 8, 9
resultado = sum(lista)
media = resultado/9
print('A média dessa lista é: ', media)